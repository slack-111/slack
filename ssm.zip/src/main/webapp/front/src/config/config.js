export default {
    baseUrl: 'http://localhost:8080/ssmx1a0c/',
    indexNav: [
        {
            name: '首页',
            url: '/index/home'
        },
        {
            name: '志愿团队',
            url: '/index/zhiyuantuandui'
        },
        {
            name: '物资去向',
            url: '/index/wuziquxiang'
        },
        {
            name: '爱心活动',
            url: '/index/aixinhuodong'
        },
        {
            name: '资金去向',
            url: '/index/zijinquxiang'
        },
        {
            name: '新闻资讯',
            url: '/index/news'
        },
    ]
}
