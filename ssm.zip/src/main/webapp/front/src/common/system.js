export function isAuth(tableName, key) {
  let role = localStorage.getItem("UserTableName");
  let menus = [{"backMenu":[{"child":[{"appFrontIcon":"cuIcon-list","buttons":["新增","查看","修改","删除"],"menu":"用户","menuJump":"列表","tableName":"yonghu"}],"menu":"用户管理"},{"child":[{"appFrontIcon":"cuIcon-explore","buttons":["新增","查看","修改","删除"],"menu":"志愿团队","menuJump":"列表","tableName":"zhiyuantuandui"}],"menu":"志愿团队管理"},{"child":[{"appFrontIcon":"cuIcon-attentionfavor","buttons":["新增","查看","修改","删除"],"menu":"公益资讯","menuJump":"列表","tableName":"gongyizixun"}],"menu":"公益资讯管理"},{"child":[{"appFrontIcon":"cuIcon-vipcard","buttons":["查看","修改","删除"],"menu":"捐赠物资","menuJump":"列表","tableName":"juanzengwuzi"}],"menu":"捐赠物资管理"},{"child":[{"appFrontIcon":"cuIcon-similar","buttons":["查看","修改","删除"],"menu":"救助信息","menuJump":"列表","tableName":"jiuzhuxinxi"}],"menu":"救助信息管理"},{"child":[{"appFrontIcon":"cuIcon-taxi","buttons":["查看","修改","删除","物品数量","类型统计"],"menu":"物资去向","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向管理"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["查看","修改","删除"],"menu":"爱心活动","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动管理"},{"child":[{"appFrontIcon":"cuIcon-keyboard","buttons":["查看","修改","删除"],"menu":"加入活动","menuJump":"列表","tableName":"jiaruhuodong"}],"menu":"加入活动管理"},{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","修改","删除","捐赠资金"],"menu":"资金去向","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向管理"},{"child":[{"appFrontIcon":"cuIcon-medal","buttons":["查看","修改"],"menu":"轮播图管理","tableName":"config"},{"appFrontIcon":"cuIcon-news","buttons":["新增","查看","修改","删除"],"menu":"新闻资讯","tableName":"news"}],"menu":"系统管理"}],"frontMenu":[{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","捐赠物资"],"menu":"志愿团队列表","menuJump":"列表","tableName":"zhiyuantuandui"}],"menu":"志愿团队模块"},{"child":[{"appFrontIcon":"cuIcon-attentionfavor","buttons":["查看"],"menu":"物资去向列表","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向模块"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["查看","加入活动"],"menu":"爱心活动列表","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动模块"},{"child":[{"appFrontIcon":"cuIcon-paint","buttons":["查看"],"menu":"资金去向列表","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向模块"}],"hasBackLogin":"是","hasBackRegister":"否","hasFrontLogin":"否","hasFrontRegister":"否","roleName":"管理员","tableName":"users"},{"backMenu":[{"child":[{"appFrontIcon":"cuIcon-vipcard","buttons":["查看","删除"],"menu":"捐赠物资","menuJump":"列表","tableName":"juanzengwuzi"}],"menu":"捐赠物资管理"},{"child":[{"appFrontIcon":"cuIcon-similar","buttons":["新增","查看","修改","删除"],"menu":"救助信息","menuJump":"列表","tableName":"jiuzhuxinxi"}],"menu":"救助信息管理"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["新增","查看","修改","删除"],"menu":"爱心活动","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动管理"}],"frontMenu":[{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","捐赠物资"],"menu":"志愿团队列表","menuJump":"列表","tableName":"zhiyuantuandui"}],"menu":"志愿团队模块"},{"child":[{"appFrontIcon":"cuIcon-attentionfavor","buttons":["查看"],"menu":"物资去向列表","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向模块"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["查看","加入活动"],"menu":"爱心活动列表","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动模块"},{"child":[{"appFrontIcon":"cuIcon-paint","buttons":["查看"],"menu":"资金去向列表","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向模块"}],"hasBackLogin":"是","hasBackRegister":"否","hasFrontLogin":"是","hasFrontRegister":"是","roleName":"用户","tableName":"yonghu"},{"backMenu":[{"child":[{"appFrontIcon":"cuIcon-vipcard","buttons":["查看","删除","审核","物资去向"],"menu":"捐赠物资","menuJump":"列表","tableName":"juanzengwuzi"}],"menu":"捐赠物资管理"},{"child":[{"appFrontIcon":"cuIcon-similar","buttons":["查看","资金去向"],"menu":"救助信息","menuJump":"列表","tableName":"jiuzhuxinxi"}],"menu":"救助信息管理"},{"child":[{"appFrontIcon":"cuIcon-taxi","buttons":["查看","删除"],"menu":"物资去向","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向管理"},{"child":[{"appFrontIcon":"cuIcon-keyboard","buttons":["查看","删除"],"menu":"加入活动","menuJump":"列表","tableName":"jiaruhuodong"}],"menu":"加入活动管理"},{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","删除"],"menu":"资金去向","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向管理"}],"frontMenu":[{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","捐赠物资"],"menu":"志愿团队列表","menuJump":"列表","tableName":"zhiyuantuandui"}],"menu":"志愿团队模块"},{"child":[{"appFrontIcon":"cuIcon-attentionfavor","buttons":["查看"],"menu":"物资去向列表","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向模块"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["查看","加入活动"],"menu":"爱心活动列表","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动模块"},{"child":[{"appFrontIcon":"cuIcon-paint","buttons":["查看"],"menu":"资金去向列表","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向模块"}],"hasBackLogin":"是","hasBackRegister":"是","hasFrontLogin":"是","hasFrontRegister":"是","roleName":"志愿团队","tableName":"zhiyuantuandui"}];
  for(let i=0;i<menus.length;i++){
    if(menus[i].tableName==role){
      for(let j=0;j<menus[i].frontMenu.length;j++){
          for(let k=0;k<menus[i].frontMenu[j].child.length;k++){
            if(tableName==menus[i].frontMenu[j].child[k].tableName){
              let buttons = menus[i].frontMenu[j].child[k].buttons.join(',');
              return buttons.indexOf(key) !== -1 || false
            }
          }
      }
    }
  }
  return false;
}

/**
 *  * 获取当前时间（yyyy-MM-dd hh:mm:ss）
 *   */
export function getCurDateTime() {
    let currentTime = new Date(),
    year = currentTime.getFullYear(),
    month = currentTime.getMonth() + 1 < 10 ? '0' + (currentTime.getMonth() + 1) : currentTime.getMonth() + 1,
    day = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate(),
    hour = currentTime.getHours(),
    minute = currentTime.getMinutes(),
    second = currentTime.getSeconds();
    return year + "-" + month + "-" + day + " " +hour +":" +minute+":"+second;
}

/**
 *  * 获取当前日期（yyyy-MM-dd）
 *   */
export function getCurDate() {
    let currentTime = new Date(),
    year = currentTime.getFullYear(),
    month = currentTime.getMonth() + 1 < 10 ? '0' + (currentTime.getMonth() + 1) : currentTime.getMonth() + 1,
    day = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
    return year + "-" + month + "-" + day;
}
