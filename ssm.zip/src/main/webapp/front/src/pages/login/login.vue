<template>
<div>
	<div class="container" :style='{"minHeight":"100vh","width":"100%","alignItems":"flex-start","background":"url(http://codegen.caihongy.cn/20230208/b696188757b941bf9da8eb105cf39976.png) no-repeat center bottom,url(http://codegen.caihongy.cn/20230208/a4679ce0961e465b848b1486df08577a.png) no-repeat center top,url() no-repeat center bottom / 100% auto","justifyContent":"flex-end","display":"flex"}'>
		<el-form ref="loginForm" :model="loginForm" :style='{"padding":"0px 40px 220px","boxShadow":"0px 0px 0px #9cd8da,inset 0px 0px 0px 0px #e0f8e8","margin":"130px auto 100px","borderColor":"#fbdbac","borderRadius":"0px","background":"url(http://codegen.caihongy.cn/20230209/5923e08fcff74454896a6391dd9f3a92.jpg) no-repeat left bottom / 100% auto,#fffdfc","borderWidth":"4px","width":"900px","position":"relative","borderStyle":"double","height":"auto"}' :rules="rules">
			<div v-if="false" :style='{"width":"100%","margin":"0 0 10px 0","fontSize":"24px","color":"#3086b9","textAlign":"center","fontWeight":"500"}'>USER / LOGIN</div>
			<div v-if="true" :style='{"margin":"40px 0 40px","borderColor":"#eee","color":"#333","textAlign":"center","borderWidth":"0px","background":"linear-gradient(180deg, rgba(253,167,69,1) 0%, rgba(253,167,69,1) 70%, rgba(253,108,66,1) 100%)","width":"100%","fontSize":"20px","lineHeight":"50px","borderStyle":"solid","fontWeight":"500"}'>爱心捐赠系统登录</div>
			<el-form-item v-if="loginType==1" class="list-item" :style='{"width":"80%","margin":"0 auto 10px"}' prop="username">
				<div v-if="false" :style='{"width":"64px","lineHeight":"40px","fontSize":"14px","color":"#ffa100"}'>账号：</div>
				<input :style='{"border":"0px solid #eacb96","padding":"0 10px","boxShadow":"0px 0px 0px #a0d8db","borderColor":"#eee","color":"#999","borderRadius":"0px","background":"#fff","borderWidth":"1px","width":"100%","fontSize":"14px","borderStyle":"solid","height":"40px"}' v-model="loginForm.username" placeholder="请输入账户">
			</el-form-item>
			<el-form-item v-if="loginType==1" class="list-item" :style='{"width":"80%","margin":"0 auto 10px"}' prop="password">
				<div v-if="false" :style='{"width":"64px","lineHeight":"40px","fontSize":"14px","color":"#ffa100"}'>密码：</div>
				<input :style='{"border":"0px solid #eacb96","padding":"0 10px","boxShadow":"0px 0px 0px #a0d8db","borderColor":"#eee","color":"#999","borderRadius":"0px","background":"#fff","borderWidth":"1px","width":"100%","fontSize":"14px","borderStyle":"solid","height":"40px"}' v-model="loginForm.password" placeholder="请输入密码" type="password">
			</el-form-item>
			<el-form-item v-if="roles.length>1" class="list-type" :style='{"width":"80%","margin":"20px auto"}' prop="role">
				<el-radio v-model="loginForm.tableName" :label="item.tableName" v-for="(item, index) in roles" :key="index" @change.native="getCurrentRow(item)">{{item.roleName}}</el-radio>
			</el-form-item>
			<el-form-item :style='{"margin":"20px auto","flexWrap":"wrap","textAlign":"center","bottom":"30px","display":"flex","width":"auto","position":"absolute","right":"40px","justifyContent":"center"}'>
				<el-button v-if="loginType==1" :style='{"border":"0","cursor":"pointer","padding":"0","boxShadow":"0px 0px 0px #9cdde0","margin":"0 10px 20px","color":"#333","display":"inline-block","minWidth":"80px","outline":"none","borderRadius":"0px","background":"linear-gradient(0deg, rgba(253,167,69,1) 0%, rgba(253,167,69,1) 70%, rgba(253,108,66,1) 100%)","width":"auto","fontSize":"14px","height":"40px"}' @click="submitForm('loginForm')">登录</el-button>
				<el-button v-if="loginType==1" :style='{"border":"0px solid #bbb","cursor":"pointer","padding":"0","boxShadow":"0px 0px 0px #ccc","margin":"0 0px","color":"#555","display":"inline-block","minWidth":"80px","outline":"none","borderRadius":"0px","background":"linear-gradient(0deg, rgba(253,167,69,1) 0%, rgba(253,167,69,1) 70%, rgba(253,108,66,1) 100%)","width":"auto","fontSize":"14px","height":"40px"}' @click="resetForm('loginForm')">重置</el-button>
                <el-upload v-if="loginType==2" :action="baseUrl + 'file/upload'" :show-file-list="false" :on-success="faceLogin">
                    <el-button :style='{"border":"0","cursor":"pointer","padding":"0","boxShadow":"0px 0px 0px #9cdde0","margin":"0 10px 20px","color":"#333","display":"inline-block","minWidth":"80px","outline":"none","borderRadius":"0px","background":"linear-gradient(0deg, rgba(253,167,69,1) 0%, rgba(253,167,69,1) 70%, rgba(253,108,66,1) 100%)","width":"auto","fontSize":"14px","height":"40px"}'>人脸识别登录</el-button>
                </el-upload>
			</el-form-item>
			<div :style='{"margin":"20px auto","alignItems":"center","flexWrap":"wrap","bottom":"120px","background":"none","display":"flex","width":"100%","position":"absolute","right":"40px","justifyContent":"flex-end"}'>
			<router-link :style='{"cursor":"pointer","padding":"0","margin":"0 0 0 10px","color":"#333","textAlign":"center","background":"linear-gradient(0deg, rgba(253,167,69,1) 0%, rgba(253,167,69,1) 70%, rgba(253,108,66,1) 100%)","fontSize":"14px","textDecoration":"none","lineHeight":"40px","minWidth":"80px"}' :to="{path: '/register', query: {role: item.tableName,pageFlag:'register'}}" v-if="item.hasFrontRegister=='是'" v-for="(item, index) in roles" :key="index">注册{{item.roleName.replace('注册','')}}</router-link>
			</div>
		</el-form>
    </div>
</div>
</template>

<script>

export default {
	//数据集合
	data() {
		return {
            baseUrl: this.$config.baseUrl,
            loginType: 1,
			roleMenus: [{"backMenu":[{"child":[{"appFrontIcon":"cuIcon-list","buttons":["新增","查看","修改","删除"],"menu":"用户","menuJump":"列表","tableName":"yonghu"}],"menu":"用户管理"},{"child":[{"appFrontIcon":"cuIcon-explore","buttons":["新增","查看","修改","删除"],"menu":"志愿团队","menuJump":"列表","tableName":"zhiyuantuandui"}],"menu":"志愿团队管理"},{"child":[{"appFrontIcon":"cuIcon-attentionfavor","buttons":["新增","查看","修改","删除"],"menu":"公益资讯","menuJump":"列表","tableName":"gongyizixun"}],"menu":"公益资讯管理"},{"child":[{"appFrontIcon":"cuIcon-vipcard","buttons":["查看","修改","删除"],"menu":"捐赠物资","menuJump":"列表","tableName":"juanzengwuzi"}],"menu":"捐赠物资管理"},{"child":[{"appFrontIcon":"cuIcon-similar","buttons":["查看","修改","删除"],"menu":"救助信息","menuJump":"列表","tableName":"jiuzhuxinxi"}],"menu":"救助信息管理"},{"child":[{"appFrontIcon":"cuIcon-taxi","buttons":["查看","修改","删除","物品数量","类型统计"],"menu":"物资去向","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向管理"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["查看","修改","删除"],"menu":"爱心活动","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动管理"},{"child":[{"appFrontIcon":"cuIcon-keyboard","buttons":["查看","修改","删除"],"menu":"加入活动","menuJump":"列表","tableName":"jiaruhuodong"}],"menu":"加入活动管理"},{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","修改","删除","捐赠资金"],"menu":"资金去向","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向管理"},{"child":[{"appFrontIcon":"cuIcon-medal","buttons":["查看","修改"],"menu":"轮播图管理","tableName":"config"},{"appFrontIcon":"cuIcon-news","buttons":["新增","查看","修改","删除"],"menu":"新闻资讯","tableName":"news"}],"menu":"系统管理"}],"frontMenu":[{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","捐赠物资"],"menu":"志愿团队列表","menuJump":"列表","tableName":"zhiyuantuandui"}],"menu":"志愿团队模块"},{"child":[{"appFrontIcon":"cuIcon-attentionfavor","buttons":["查看"],"menu":"物资去向列表","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向模块"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["查看","加入活动"],"menu":"爱心活动列表","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动模块"},{"child":[{"appFrontIcon":"cuIcon-paint","buttons":["查看"],"menu":"资金去向列表","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向模块"}],"hasBackLogin":"是","hasBackRegister":"否","hasFrontLogin":"否","hasFrontRegister":"否","roleName":"管理员","tableName":"users"},{"backMenu":[{"child":[{"appFrontIcon":"cuIcon-vipcard","buttons":["查看","删除"],"menu":"捐赠物资","menuJump":"列表","tableName":"juanzengwuzi"}],"menu":"捐赠物资管理"},{"child":[{"appFrontIcon":"cuIcon-similar","buttons":["新增","查看","修改","删除"],"menu":"救助信息","menuJump":"列表","tableName":"jiuzhuxinxi"}],"menu":"救助信息管理"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["新增","查看","修改","删除"],"menu":"爱心活动","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动管理"}],"frontMenu":[{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","捐赠物资"],"menu":"志愿团队列表","menuJump":"列表","tableName":"zhiyuantuandui"}],"menu":"志愿团队模块"},{"child":[{"appFrontIcon":"cuIcon-attentionfavor","buttons":["查看"],"menu":"物资去向列表","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向模块"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["查看","加入活动"],"menu":"爱心活动列表","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动模块"},{"child":[{"appFrontIcon":"cuIcon-paint","buttons":["查看"],"menu":"资金去向列表","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向模块"}],"hasBackLogin":"是","hasBackRegister":"否","hasFrontLogin":"是","hasFrontRegister":"是","roleName":"用户","tableName":"yonghu"},{"backMenu":[{"child":[{"appFrontIcon":"cuIcon-vipcard","buttons":["查看","删除","审核","物资去向"],"menu":"捐赠物资","menuJump":"列表","tableName":"juanzengwuzi"}],"menu":"捐赠物资管理"},{"child":[{"appFrontIcon":"cuIcon-similar","buttons":["查看","资金去向"],"menu":"救助信息","menuJump":"列表","tableName":"jiuzhuxinxi"}],"menu":"救助信息管理"},{"child":[{"appFrontIcon":"cuIcon-taxi","buttons":["查看","删除"],"menu":"物资去向","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向管理"},{"child":[{"appFrontIcon":"cuIcon-keyboard","buttons":["查看","删除"],"menu":"加入活动","menuJump":"列表","tableName":"jiaruhuodong"}],"menu":"加入活动管理"},{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","删除"],"menu":"资金去向","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向管理"}],"frontMenu":[{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","捐赠物资"],"menu":"志愿团队列表","menuJump":"列表","tableName":"zhiyuantuandui"}],"menu":"志愿团队模块"},{"child":[{"appFrontIcon":"cuIcon-attentionfavor","buttons":["查看"],"menu":"物资去向列表","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向模块"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["查看","加入活动"],"menu":"爱心活动列表","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动模块"},{"child":[{"appFrontIcon":"cuIcon-paint","buttons":["查看"],"menu":"资金去向列表","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向模块"}],"hasBackLogin":"是","hasBackRegister":"是","hasFrontLogin":"是","hasFrontRegister":"是","roleName":"志愿团队","tableName":"zhiyuantuandui"}],
			loginForm: {
				username: '',
				password: '',
				tableName: '',
				code: '',
			},
			role: '',
            roles: [],
			rules: {
				username: [
					{ required: true, message: '请输入账户', trigger: 'blur' }
				],
				password: [
					{ required: true, message: '请输入密码', trigger: 'blur' }
				]
			},
			codes: [{
				num: 1,
				color: '#000',
				rotate: '10deg',
				size: '16px'
			}, {
				num: 2,
				color: '#000',
				rotate: '10deg',
				size: '16px'
			}, {
				num: 3,
				color: '#000',
				rotate: '10deg',
				size: '16px'
			}, {
				num: 4,
				color: '#000',
				rotate: '10deg',
				size: '16px'
			}]
		}
	},
	created() {
        for(let item in this.roleMenus) {
            if(this.roleMenus[item].hasFrontLogin=='是') {
                this.roles.push(this.roleMenus[item]);
            }
        }
	},
	mounted() {
	},
    //方法集合
    methods: {
		randomString() {
			var len = 4;
			var chars = [
			  'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k',
			  'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
			  'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G',
			  'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
			  'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2',
			  '3', '4', '5', '6', '7', '8', '9'
			]
			var colors = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f']
			var sizes = ['14', '15', '16', '17', '18']
			
			var output = []
			for (var i = 0; i < len; i++) {
			  // 随机验证码
			  var key = Math.floor(Math.random() * chars.length)
			  this.codes[i].num = chars[key]
			  // 随机验证码颜色
			  var code = '#'
			  for (var j = 0; j < 6; j++) {
			    var key = Math.floor(Math.random() * colors.length)
			    code += colors[key]
			  }
			  this.codes[i].color = code
			  // 随机验证码方向
			  var rotate = Math.floor(Math.random() * 45)
			  var plus = Math.floor(Math.random() * 2)
			  if (plus == 1) rotate = '-' + rotate
			  this.codes[i].rotate = 'rotate(' + rotate + 'deg)'
			  // 随机验证码字体大小
			  var size = Math.floor(Math.random() * sizes.length)
			  this.codes[i].size = sizes[size] + 'px'
			}
		},
      getCurrentRow(row) {
        this.role = row.roleName;
      },
      submitForm(formName) {
        if (this.roles.length!=1) {
            if (!this.role) {
                this.$message.error("请选择登录用户类型");
                return false;
            }
        } else {
            this.role = this.roles[0].roleName;
            this.loginForm.tableName = this.roles[0].tableName;
        }
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$http.get(`${this.loginForm.tableName}/login`, {params: this.loginForm}).then(res => {
              if (res.data.code === 0) {
                localStorage.setItem('Token', res.data.token);
                localStorage.setItem('UserTableName', this.loginForm.tableName);
                localStorage.setItem('username', this.loginForm.username);
                localStorage.setItem('adminName', this.loginForm.username);
                localStorage.setItem('sessionTable', this.loginForm.tableName);
                localStorage.setItem('role', this.role);
                localStorage.setItem('keyPath', this.$config.indexNav.length+2);
                this.$router.push('/index/center');
                this.$message({
                  message: '登录成功',
                  type: 'success',
                  duration: 1500,
                });
              } else {
                this.$message.error(res.data.msg);
              }
            });
          } else {
            return false;
          }
        });
      },
      resetForm(formName) {
        this.$refs[formName].resetFields();
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
	.container {
		position: relative;
		background: url(http://codegen.caihongy.cn/20230208/b696188757b941bf9da8eb105cf39976.png) no-repeat center bottom,url(http://codegen.caihongy.cn/20230208/a4679ce0961e465b848b1486df08577a.png) no-repeat center top,url() no-repeat center bottom / 100% auto;
		
		.el-form-item {
		  & /deep/ .el-form-item__content {
		    width: 100%;
		  }
		}
		
		.list-item /deep/ .el-input .el-input__inner {
			border: 0px solid #eacb96;
			border-radius: 0px;
			padding: 0 10px;
			box-shadow: 0px 0px 0px #a0d8db;
			color: #999;
			background: #fff;
			width: 100%;
			font-size: 14px;
			border-color: #eee;
			border-width: 1px;
			border-style: solid;
			height: 40px;
		}
		
		.list-code /deep/ .el-input .el-input__inner {
			border: 0px solid #eacb96;
			padding: 0 10px;
			color: #999;
			display: inline-block;
			vertical-align: middle;
			font-size: 14px;
			border-color: #eee;
			border-radius: 0px;
			box-shadow: 0px 0px 0px #a0d8db;
			outline: none;
			background: #fff;
			width: calc(100% - 100px);
			border-width: 1px;
			border-style: solid;
			height: 40px;
		}
		
		.list-type /deep/ .el-radio__input .el-radio__inner {
			background: rgba(53, 53, 53, 0);
			border-color: #666666;
		}
		.list-type /deep/ .el-radio__input.is-checked .el-radio__inner {
			background: #fd6c42;
			border-color: #fd6c42;
		}
		.list-type /deep/ .el-radio__label {
			color: #666666;
			font-size: 14px;
		}
		.list-type /deep/ .el-radio__input.is-checked+.el-radio__label {
			color: #fd6c42;
			font-size: 14px;
		}
	}
</style>
