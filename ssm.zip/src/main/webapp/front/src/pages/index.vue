<template>
	<div class="main-containers">
		<div class="top-container" :style='{"boxShadow":"0 0px 0px rgba(64, 158, 255, .3)","padding":"0 20px","margin":"0 auto","alignItems":"center","display":"flex","right":"0","justifyContent":"flex-end","overflow":"hidden","top":"0","left":"0","background":"#BE8E56","width":"100%","lineHeight":"64px","position":"fixed","height":"44px","zIndex":"1002"}'>
			<img v-if='false' :style='{"width":"44px","objectFit":"cover","borderRadius":"100%","display":"block","height":"44px"}' src='http://codegen.caihongy.cn/20201114/7856ba26477849ea828f481fa2773a95.jpg'>
			<div v-if="true" :style='{"margin":"0 20%","color":"#fff","top":"0","textAlign":"center","background":"none","display":"inline-block","width":"60%","fontSize":"22px","lineHeight":"44px","position":"absolute"}'>爱心捐赠系统</div>
			<div>
				<div v-if="false" :style='{"color":"#fff","fontSize":"16px","display":"inline-block"}'>0753-1234567</div>
				<div v-if="Token" :style='{"color":"#fff","fontSize":"16px","display":"inline-block"}'>{{username}}</div>
				<el-button v-if="!Token" @click="toLogin()" :style='{"border":"0px solid #00adb5","padding":"0 10px","boxShadow":"0px 0px 0px #ccc","margin":"10px 0 12px","color":"#fff","borderRadius":"2px","background":"#fd6c42","display":"inline-block","fontSize":"14px","lineHeight":"30px","minWidth":"60px","height":"30px"}'>登录/注册</el-button>
                <el-button v-if="Token" @click="logout" :style='{"border":"0px solid #00adb5","padding":"0 12px","boxShadow":"0px 0px 0px #bbb","margin":"10px 20px 0 10px","color":"#666","borderRadius":"2px","background":"#fff","display":"inline-block","fontSize":"14px","lineHeight":"30px","minWidth":"60px","height":"30px"}'>退出</el-button>
			</div>
		</div>
		
		
		<div class="body-containers" :style='"horizontal" == "vertical" ? {"minHeight":"100vh","padding":"64px 0 0","margin":"0 0 0 210px","position":"relative","background":"url(http://codegen.caihongy.cn/20230101/3b575ca380e14124bc1945e639178e9d.png) fixed no-repeat center top / 100% 100%,rgba(64, 158, 255, .3)","display":"block"} : {"minHeight":"100vh","padding":"0","margin":"0","position":"relative","background":"#fff"}'>
			<div class="menu-preview" :style='{"borderColor":"#efefef","margin":"44px auto 0px","background":"#ff9a3c","borderWidth":"0","width":"100%","position":"fixed","borderStyle":"solid","height":"50px","zIndex":"999"}'>
				<el-menu class="el-menu-horizontal-demo" :style='{"border":"0","listStyle":"none","margin":"0 auto","flexWrap":"wrap","textAlign":"center","background":"url(http://codegen.caihongy.cn/20230208/a4679ce0961e465b848b1486df08577a.png) no-repeat center top","display":"flex","position":"relative","justifyContent":"center","height":"100%"}' :default-active="activeIndex" :unique-opened="true" mode="horizontal" :router="true" @select="handleSelect">
					<el-image v-if="false" :style='{"width":"44px","margin":"8px 10px 8px 0","objectFit":"cover","borderRadius":"100%","float":"left","height":"44px"}' src="http://codegen.caihongy.cn/20201114/7856ba26477849ea828f481fa2773a95.jpg" fit="cover"></el-image>
					<el-menu-item v-for="(menu, index) in menuList" :index="index + ''" :key="index" :route="menu.url">
						<i v-if="true" :style='{"padding":"0 10px","margin":"0","color":"inherit","width":"14px","lineHeight":"50px","fontSize":"16px","height":"50px"}' :class="iconArr[index]"></i>
						<span :style='{"padding":"0 10px","lineHeight":"50px","fontSize":"16px","color":"inherit","height":"50px"}'>{{menu.name}}</span>
					</el-menu-item>
					<el-menu-item @click="goBackend">
						<i v-if="true" :style='{"padding":"0 10px","margin":"0","color":"inherit","width":"14px","lineHeight":"50px","fontSize":"16px","height":"50px"}' class="el-icon-box"></i>
						<span :style='{"padding":"0 10px","lineHeight":"50px","fontSize":"16px","color":"inherit","height":"50px"}'>后台管理</span>
					</el-menu-item>
					<el-menu-item :index="menuList.length + 2 + ''" v-if="Token && notAdmin" @click="goMenu('/index/center')">
						<i v-if="true" :style='{"padding":"0 10px","margin":"0","color":"inherit","width":"14px","lineHeight":"50px","fontSize":"16px","height":"50px"}' class="el-icon-user"></i>
						<span :style='{"padding":"0 10px","lineHeight":"50px","fontSize":"16px","color":"inherit","height":"50px"}'>个人中心</span>
					</el-menu-item>
				</el-menu>
			</div>
			
			<div class="banner-preview" :style='{"width":"100%","padding":"170px 7% 0","margin":"0 0 20px","background":"url(http://codegen.caihongy.cn/20230208/a4679ce0961e465b848b1486df08577a.png) no-repeat center top","height":"720px"}'>
				<el-carousel :style='{"width":"100%","margin":"0 auto"}' trigger="click" indicator-position="inside" arrow="always" type="default" direction="horizontal" height="550px" :autoplay="true" :interval="5000" :loop="true">
					<el-carousel-item :style='{"borderRadius":"0","width":"100%","height":"100%"}' v-for="item in carouselList" :key="item.id">
						<el-image :style='{"objectFit":"cover","width":"100%","height":"100%"}' :src="baseUrl + item.value" fit="cover"></el-image>
					</el-carousel-item>
				</el-carousel>
			</div>
			
			<router-view></router-view>
			
			<div class="bottom-preview" :style='{"minHeight":"150px","padding":"20px 0","borderColor":"#222","alignItems":"center","color":"#fff","background":"#434343","flexDirection":"column","borderWidth":"0 0 40px","display":"flex","width":"100%","borderStyle":"solid","justifyContent":"center"}'>
			    <img :style='{"width":"44px","objectFit":"cover","borderRadius":"100%","display":"none","height":"44px"}' src="http://codegen.caihongy.cn/20201114/7856ba26477849ea828f481fa2773a95.jpg" >
			    <div :style='{"margin":"0","fontSize":"14px","lineHeight":"28px","color":"#fff"}'></div>
			    <div :style='{"margin":"10px 0 0","fontSize":"14px","lineHeight":"28px","color":"#fff"}'></div>
			    <div :style='{"margin":"10px 0 0","fontSize":"14px","lineHeight":"28px","color":"#fff"}'></div>
			</div>
		</div>
		
	</div>
</template>

<script>
import Vue from 'vue'
export default {
    data() {
		return {
            activeIndex: '0',
			roleMenus: [{"backMenu":[{"child":[{"appFrontIcon":"cuIcon-list","buttons":["新增","查看","修改","删除"],"menu":"用户","menuJump":"列表","tableName":"yonghu"}],"menu":"用户管理"},{"child":[{"appFrontIcon":"cuIcon-explore","buttons":["新增","查看","修改","删除"],"menu":"志愿团队","menuJump":"列表","tableName":"zhiyuantuandui"}],"menu":"志愿团队管理"},{"child":[{"appFrontIcon":"cuIcon-attentionfavor","buttons":["新增","查看","修改","删除"],"menu":"公益资讯","menuJump":"列表","tableName":"gongyizixun"}],"menu":"公益资讯管理"},{"child":[{"appFrontIcon":"cuIcon-vipcard","buttons":["查看","修改","删除"],"menu":"捐赠物资","menuJump":"列表","tableName":"juanzengwuzi"}],"menu":"捐赠物资管理"},{"child":[{"appFrontIcon":"cuIcon-similar","buttons":["查看","修改","删除"],"menu":"救助信息","menuJump":"列表","tableName":"jiuzhuxinxi"}],"menu":"救助信息管理"},{"child":[{"appFrontIcon":"cuIcon-taxi","buttons":["查看","修改","删除","物品数量","类型统计"],"menu":"物资去向","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向管理"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["查看","修改","删除"],"menu":"爱心活动","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动管理"},{"child":[{"appFrontIcon":"cuIcon-keyboard","buttons":["查看","修改","删除"],"menu":"加入活动","menuJump":"列表","tableName":"jiaruhuodong"}],"menu":"加入活动管理"},{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","修改","删除","捐赠资金"],"menu":"资金去向","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向管理"},{"child":[{"appFrontIcon":"cuIcon-medal","buttons":["查看","修改"],"menu":"轮播图管理","tableName":"config"},{"appFrontIcon":"cuIcon-news","buttons":["新增","查看","修改","删除"],"menu":"新闻资讯","tableName":"news"}],"menu":"系统管理"}],"frontMenu":[{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","捐赠物资"],"menu":"志愿团队列表","menuJump":"列表","tableName":"zhiyuantuandui"}],"menu":"志愿团队模块"},{"child":[{"appFrontIcon":"cuIcon-attentionfavor","buttons":["查看"],"menu":"物资去向列表","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向模块"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["查看","加入活动"],"menu":"爱心活动列表","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动模块"},{"child":[{"appFrontIcon":"cuIcon-paint","buttons":["查看"],"menu":"资金去向列表","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向模块"}],"hasBackLogin":"是","hasBackRegister":"否","hasFrontLogin":"否","hasFrontRegister":"否","roleName":"管理员","tableName":"users"},{"backMenu":[{"child":[{"appFrontIcon":"cuIcon-vipcard","buttons":["查看","删除"],"menu":"捐赠物资","menuJump":"列表","tableName":"juanzengwuzi"}],"menu":"捐赠物资管理"},{"child":[{"appFrontIcon":"cuIcon-similar","buttons":["新增","查看","修改","删除"],"menu":"救助信息","menuJump":"列表","tableName":"jiuzhuxinxi"}],"menu":"救助信息管理"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["新增","查看","修改","删除"],"menu":"爱心活动","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动管理"}],"frontMenu":[{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","捐赠物资"],"menu":"志愿团队列表","menuJump":"列表","tableName":"zhiyuantuandui"}],"menu":"志愿团队模块"},{"child":[{"appFrontIcon":"cuIcon-attentionfavor","buttons":["查看"],"menu":"物资去向列表","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向模块"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["查看","加入活动"],"menu":"爱心活动列表","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动模块"},{"child":[{"appFrontIcon":"cuIcon-paint","buttons":["查看"],"menu":"资金去向列表","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向模块"}],"hasBackLogin":"是","hasBackRegister":"否","hasFrontLogin":"是","hasFrontRegister":"是","roleName":"用户","tableName":"yonghu"},{"backMenu":[{"child":[{"appFrontIcon":"cuIcon-vipcard","buttons":["查看","删除","审核","物资去向"],"menu":"捐赠物资","menuJump":"列表","tableName":"juanzengwuzi"}],"menu":"捐赠物资管理"},{"child":[{"appFrontIcon":"cuIcon-similar","buttons":["查看","资金去向"],"menu":"救助信息","menuJump":"列表","tableName":"jiuzhuxinxi"}],"menu":"救助信息管理"},{"child":[{"appFrontIcon":"cuIcon-taxi","buttons":["查看","删除"],"menu":"物资去向","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向管理"},{"child":[{"appFrontIcon":"cuIcon-keyboard","buttons":["查看","删除"],"menu":"加入活动","menuJump":"列表","tableName":"jiaruhuodong"}],"menu":"加入活动管理"},{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","删除"],"menu":"资金去向","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向管理"}],"frontMenu":[{"child":[{"appFrontIcon":"cuIcon-send","buttons":["查看","捐赠物资"],"menu":"志愿团队列表","menuJump":"列表","tableName":"zhiyuantuandui"}],"menu":"志愿团队模块"},{"child":[{"appFrontIcon":"cuIcon-attentionfavor","buttons":["查看"],"menu":"物资去向列表","menuJump":"列表","tableName":"wuziquxiang"}],"menu":"物资去向模块"},{"child":[{"appFrontIcon":"cuIcon-vip","buttons":["查看","加入活动"],"menu":"爱心活动列表","menuJump":"列表","tableName":"aixinhuodong"}],"menu":"爱心活动模块"},{"child":[{"appFrontIcon":"cuIcon-paint","buttons":["查看"],"menu":"资金去向列表","menuJump":"列表","tableName":"zijinquxiang"}],"menu":"资金去向模块"}],"hasBackLogin":"是","hasBackRegister":"是","hasFrontLogin":"是","hasFrontRegister":"是","roleName":"志愿团队","tableName":"zhiyuantuandui"}],
			baseUrl: '',
			carouselList: [],
			menuList: [],
			form: {
				ask: '',
				userid: localStorage.getItem('userid')
			},
			Token: localStorage.getItem('Token'),
            username: localStorage.getItem('username'),
            notAdmin: localStorage.getItem('sessionTable')!='"users"',
			timer: '',
			iconArr: [
				'el-icon-star-off',
				'el-icon-goods',
				'el-icon-warning',
				'el-icon-question',
				'el-icon-info',
				'el-icon-help',
				'el-icon-picture-outline-round',
				'el-icon-camera-solid',
				'el-icon-video-camera-solid',
				'el-icon-video-camera',
				'el-icon-bell',
				'el-icon-s-cooperation',
				'el-icon-s-order',
				'el-icon-s-platform',
				'el-icon-s-operation',
				'el-icon-s-promotion',
				'el-icon-s-release',
				'el-icon-s-ticket',
				'el-icon-s-management',
				'el-icon-s-open',
				'el-icon-s-shop',
				'el-icon-s-marketing',
				'el-icon-s-flag',
				'el-icon-s-comment',
				'el-icon-s-finance',
				'el-icon-s-claim',
				'el-icon-s-opportunity',
				'el-icon-s-data',
				'el-icon-s-check'
			],	
		}
    },
    created() {
		this.baseUrl = this.$config.baseUrl;
		this.menuList = this.$config.indexNav;
		this.getCarousel();
    },
    mounted() {
        this.activeIndex = localStorage.getItem('keyPath') || '0';
    },
    watch: {
        $route(newValue) {
            let that = this
            let url = window.location.href
            let arr = url.split('#')
            for (let x in this.menuList) {
                if (newValue.path == this.menuList[x].url) {
                    this.activeIndex = x
                }
            }
            this.Token = localStorage.getItem('Token')
        },
    },
    methods: {
        handleSelect(keyPath) {
            if (keyPath) {
                localStorage.setItem('keyPath', keyPath)
            }
        },
		toLogin() {
		  this.$router.push('/login');
		},
        logout() {
            localStorage.clear();
            Vue.http.headers.common['Token'] = "";
            this.$router.push('/index/home');
            this.activeIndex = '0'
            localStorage.setItem('keyPath', this.activeIndex)
            this.Token = ''
            this.$forceUpdate()
            this.$message({
                message: '登出成功',
                type: 'success',
                duration: 1000,
            });
        },
		getCarousel() {
			this.$http.get('config/list', {params: { page: 1, limit: 3 }}).then(res => {
				if (res.data.code == 0) {
					this.carouselList = res.data.data.list;
				}
			});
		},
		goBackend() {
			window.open(`${this.$config.baseUrl}admin/dist/index.html`, "_blank");
		},
		goMenu(path) {
            if (!localStorage.getItem('Token')) {
                this.toLogin();
            } else {
                this.$router.push(path);
            }
		},
    }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
	.menu-preview {
	  .el-scrollbar {
	    height: 100%;
	
	    & /deep/ .scrollbar-wrapper {
	      overflow-x: hidden;
	    }
	  }
	}
	
	
	.menu-preview .el-menu-horizontal-demo .el-menu-item {
		cursor: pointer;
		padding: 0 10px;
		margin: 0;
		color: #fff;
		white-space: nowrap;
		display: flex;
		font-size: 16px;
		border-color: #936837;
		line-height: 50px;
		border-radius: 0;
		background: none;
		width: auto;
		justify-content: center;
		border-width: 0px;
		position: relative;
		border-style: solid;
		list-style: none;
		text-align: center;
		min-width: 80px;
		height: 50px;
	}
	
	.menu-preview .el-menu-horizontal-demo .el-menu-item:hover {
		cursor: pointer;
		padding: 0 10px;
		margin: 0;
		color: #fff;
		white-space: nowrap;
		font-size: 16px;
		border-color: #936837;
		line-height: 50px;
		border-radius: 0;
		background: none;
		width: auto;
		border-width: 0 0 2px;
		position: relative;
		border-style: solid;
		list-style: none;
		min-width: 80px;
		height: 50px;
	}
	
	.menu-preview .el-menu-horizontal-demo .el-menu-item.is-active {
		cursor: pointer;
		padding: 0 10px;
		margin: 0;
		color: #fff;
		white-space: nowrap;
		font-size: 16px;
		border-color: #936837;
		line-height: 50px;
		border-radius: 0;
		background: none;
		width: auto;
		border-width: 0 0 2px;
		position: relative;
		border-style: solid;
		list-style: none;
		min-width: 80px;
		height: 50px;
	}
	
	.banner-preview {
	  .el-carousel /deep/ .el-carousel__indicator button {
	    width: 0;
	    height: 0;
	    display: none;
	  }
	}
	
	.banner-preview .el-carousel /deep/ .el-carousel__container .el-carousel__arrow--left {
		width: 36px;
		font-size: 12px;
		height: 36px;
	}
	
	.banner-preview .el-carousel /deep/ .el-carousel__container .el-carousel__arrow--left:hover {
		background: #2087c3;
	}
	
	.banner-preview .el-carousel /deep/ .el-carousel__container .el-carousel__arrow--right {
		width: 36px;
		font-size: 12px;
		height: 36px;
	}
	
	.banner-preview .el-carousel /deep/ .el-carousel__container .el-carousel__arrow--right:hover {
		background: #2087c3;
	}

	.banner-preview .el-carousel /deep/ .el-carousel__indicators {
		padding: 0;
		margin: 0 0 12px 0;
		z-index: 2;
		position: absolute;
		list-style: none;
	}
	
	.banner-preview .el-carousel /deep/ .el-carousel__indicators li {
		border-radius: 50%;
		padding: 0;
		margin: 0 4px;
		background: #fff;
		display: inline-block;
		width: 12px;
		opacity: 0.4;
		transition: 0.3s;
		height: 12px;
	}
	
	.banner-preview .el-carousel /deep/ .el-carousel__indicators li:hover {
		border-radius: 50%;
		padding: 0;
		margin: 0 4px;
		background: #fff;
		display: inline-block;
		width: 12px;
		opacity: 0.7;
		height: 12px;
	}
	
	.banner-preview .el-carousel /deep/ .el-carousel__indicators li.is-active {
		border-radius: 50%;
		padding: 0;
		margin: 0 4px;
		background: #fff;
		display: inline-block;
		width: 12px;
		opacity: 1;
		height: 12px;
	}

    .chat-content {
      .left-content {
          width: 100%;
          text-align: left;
      }
      .right-content {
          width: 100%;
          text-align: right;
      }
    }
</style>
