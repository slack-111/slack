<template>
<div class="home-preview" :style='{"width":"100%","margin":"0px auto","flexWrap":"wrap","justifyContent":"center","display":"flex"}'>

		
											<div class="news" :style='{"padding":"0 7%","margin":"40px 0 0","borderColor":"#98c6e2","overflow":"hidden","borderRadius":"0px","background":"none","borderWidth":"0px","width":"100%","position":"relative","borderStyle":"dotted","height":"auto","order":"2"}'>
		<div v-if="false" class="idea newsIdea" :style='{"padding":"0","margin":"0 auto","flexWrap":"wrap","background":"none","display":"flex","width":"1200px","justifyContent":"space-between"}'>
			<div class="box1" :style='{"width":"1200px","margin":"0 auto","position":"absolute","top":"74px","background":"#08b344","height":"1px"}'></div>
			<div class="box2" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
			<div class="box3" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
			<div class="box4" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
			<div class="box5" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
			<div class="box6" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
			<div class="box7" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
			<div class="box8" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
			<div class="box9" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
			<div class="box10" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		</div>
		
		<div class="title" :style='{"padding":"0px 20px 0 0px","margin":"0px auto 20px","borderRadius":"0px","background":"url(http://codegen.caihongy.cn/20230208/a6f9d67e1ec04a1dbbb264deb83c53bc.png) no-repeat right top / auto 100%,url(http://codegen.caihongy.cn/20230208/bd01c0afeace43b5bf2e9be87a292858.png) no-repeat left top / auto 100%,url(http://codegen.caihongy.cn/20230208/128206ec886647b8ba4092200f05299a.png) repeat-x center top / auto 100%","width":"80%","position":"relative","height":"90px"}'>
			<span :style='{"padding":"0 20px 0 60px","color":"#4e4e4e","background":"none","fontSize":"24px","lineHeight":" 76px","textShadow":"0px 0px 0px #eee","fontWeight":"600"}'>新闻资讯</span>
		</div>
		
			
			
			
			
			
			
			
			<!-- 样式七 -->
		<div v-if="newsList.length" class="list list7 index-pv1" :style='{"width":"100%","padding":"40px 0 40px","background":"none","justifyContent":"space-between","display":"flex","height":"auto"}'>
		  <div v-for="(item,index) in newsList" v-if="index<4" :key="index" @click="toDetail('newsDetail', item)" class="new7-list-item animation-box" style="cursor: pointer;" :style='{"cursor":"pointer","width":"23.5%","boxShadow":"0px 26px 26px -30px #816653","margin":"0 0px","background":"linear-gradient(180deg, rgba(253,167,69,1) 0%, rgba(253,167,69,1) 70%, rgba(253,108,66,1) 100%)","height":"auto"}'>
		    <img :style='{"objectFit":"cover","width":"100%","height":"280px"}' style="box-sizing: border-box;object-fit: cover;width: 100%;height: 250px;" :src="baseUrl + item.picture">
		    <div :style='{"padding":"0 10px","whiteSpace":"nowrap","overflow":"hidden","color":"#fff","fontSize":"16px","lineHeight":"40px","textOverflow":"ellipsis"}' class="new7-list-item-title line1">{{ item.title }}</div>
		    <div :style='{"padding":"0 10px","overflow":"hidden","color":"#fff","fontSize":"14px","lineHeight":"24px","textIndent":"2em","height":"72px"}' class="new7-list-item-descript line1">{{ item.introduction }}</div>
		    <div :style='{"padding":"0 10px","fontSize":"12px","lineHeight":"32px","color":"#eee"}' class="new7-list-item-time">{{ item.addtime.split(' ')[0] }}</div>
		    <div :style='{"width":"100%","padding":"0 10px","alignItems":"center","justifyContent":"space-between","display":"none","height":"auto"}'>
		      <div :style='{"color":"#666","fontSize":"14px","lineHeight":"24px"}'>新闻咨询</div>
		      <div :style='{"color":"#999","fontSize":"14px","lineHeight":"24px"}'>→</div>
		    </div>
		  </div>
		</div>
			
			
			
			
		<div @click="moreBtn('news')" :style='{"cursor":"pointer","boxShadow":"0px 0px 0px #ddd5c6,inset 0px 0px 0px 0px #ffa100","padding":"0 12px 0 20px","margin":"0px auto 0","borderColor":"#9dcde9","textAlign":"center","display":"block","right":"calc(17% + 20px)","borderRadius":"0px","top":"18px","background":"none","borderWidth":"0px","width":"auto","lineHeight":"40px","position":"absolute","borderStyle":"dotted"}'>
			<span :style='{"color":"#333","background":"none","fontSize":"16px"}'>查看更多</span>
			<i v-if="true" :style='{"color":"#333","fontSize":"16px","display":"inline-block"}' class="el-icon-d-arrow-right"></i>
		</div>
		
		</div>
			




<div class="lists" :style='{"padding":"0px","boxShadow":"0px 0px 0px #eee","margin":"40px 0 0px","borderColor":"#98c6e2","display":"block","borderRadius":"0px","flexWrap":"wrap","background":"url() no-repeat center bottom / 100% auto,#fff","borderWidth":"0 0 0px","width":"100%","position":"relative","borderStyle":"dotted","height":"auto","order":"4"}'>
	
	<div class="title" :style='{"width":"80%","padding":"0px 20px 0 0px","margin":"0px auto 40px","position":"relative","background":"url(http://codegen.caihongy.cn/20230208/a6f9d67e1ec04a1dbbb264deb83c53bc.png) no-repeat right top / auto 100%,url(http://codegen.caihongy.cn/20230208/bd01c0afeace43b5bf2e9be87a292858.png) no-repeat left top / auto 100%,url(http://codegen.caihongy.cn/20230208/128206ec886647b8ba4092200f05299a.png) repeat-x center top / auto 100%","height":"90px"}'>
	  <span :style='{"padding":"0 20px 0 60px","color":"#4e4e4e","background":"none","fontSize":"24px","lineHeight":"76px","textShadow":"0px 0px 0px #eee","fontWeight":"600"}'>志愿团队展示</span>
	</div>
	
	
	
	<!-- 样式二 -->
	<div class="list list2 index-pv1" :style='{"padding":"0 7%","flexWrap":"wrap","background":"none","display":"flex","width":"100%","justifyContent":"space-between","height":"auto"}'>
		<div :style='{"cursor":"pointer","padding":"0px","boxShadow":"0px 0px 0px #eee","margin":"0 0 80px","borderColor":"#eee","display":"flex","flexWrap":"wrap","background":"#fff","borderWidth":"0px","width":"48%","fontSize":"0","position":"relative","borderStyle":"solid","height":"320px"}' v-for="(item,index) in zhiyuantuanduiList" class="list-item animation-box" :key="index" @click="toDetail('zhiyuantuanduiDetail', item)">
			<img :style='{"padding":"0px","borderColor":"#9dcde9","margin":"40px 0 0","objectFit":"cover","borderWidth":"0px","display":"inline-block","width":"50%","borderStyle":"dotted","height":"100%"}' v-if="preHttp(item.fengmian)" :src="item.fengmian.split(',')[0]" alt="" />
			<img :style='{"padding":"0px","borderColor":"#9dcde9","margin":"40px 0 0","objectFit":"cover","borderWidth":"0px","display":"inline-block","width":"50%","borderStyle":"dotted","height":"100%"}' v-else :src="baseUrl +  (item.fengmian?item.fengmian.split(',')[0]:'')" alt="" />
			<div :style='{"padding":"10px 0px","borderColor":"#f3d7ca #f3d7ca #f3d7ca","overflow":"hidden","alignItems":"center","background":"linear-gradient(180deg, rgba(253,167,69,1) 0%, rgba(253,167,69,1) 50%, rgba(253,108,66,1) 100%)","borderWidth":"0 10px 0","display":"flex","width":"50%","borderStyle":"solid","justifyContent":"center","height":"100%"}' class="item-info">
				<div class="name line1" :style='{"padding":"10px","borderColor":"#9dcde9","margin":"0 10px 0 0","color":"#fff","alignItems":"center","textAlign":"center","display":"flex","justifyContent":"center","overflow":"hidden","borderWidth":"0 0 0px","width":"40px","lineHeight":"1.2","fontSize":"16px","borderStyle":"dotted"}'>{{item.tuanduizhanghao}}</div>
				<div class="name line1" :style='{"padding":"10px","borderColor":"#9dcde9","margin":"0 10px 0 0","color":"#fff","alignItems":"center","textAlign":"center","display":"flex","justifyContent":"center","overflow":"hidden","borderWidth":"0 0 0px","width":"40px","lineHeight":"1.2","fontSize":"16px","borderStyle":"dotted"}'>{{item.tuanduimingcheng}}</div>
				<div class="name line1" :style='{"padding":"10px","borderColor":"#9dcde9","margin":"0 10px 0 0","color":"#fff","alignItems":"center","textAlign":"center","display":"flex","justifyContent":"center","overflow":"hidden","borderWidth":"0 0 0px","width":"40px","lineHeight":"1.2","fontSize":"16px","borderStyle":"dotted"}'>{{item.fuzeren}}</div>
			</div>
		</div>
	</div>
	
	
	
	
	
	
	
	
	<div @click="moreBtn('zhiyuantuandui')" :style='{"cursor":"pointer","padding":"0 20px","margin":"0px auto 0","borderColor":"#9dcde9","textAlign":"center","display":"inline-block","minWidth":"120px","right":"calc(10% + 20px)","borderRadius":"0px","top":"18px","background":"none","borderWidth":"0px","width":"auto","lineHeight":"40px","position":"absolute","borderStyle":"dotted"}'>
		<span :style='{"padding":"0px","borderColor":"#ccc","margin":"0","color":"#333","background":"none","borderWidth":"0","display":"inline-block","width":"auto","fontSize":"15px","lineHeight":"40px","borderStyle":"solid","height":"40px"}'>查看更多</span>
		<i v-if="true" :style='{"padding":"0","borderColor":"#ccc","margin":"0","color":"#333","borderWidth":"0px","background":"none","display":"inline-block","width":"auto","fontSize":"15px","lineHeight":"40px","borderStyle":"solid","height":"40px"}' class="el-icon-d-arrow-right"></i>
	</div>
	
	<div v-if="true" class="idea" :style='{"padding":"0px","margin":"50px 0 0","flexWrap":"wrap","background":"none","display":"flex","width":"100%","justifyContent":"space-between"}'>
		<div class="box1" :style='{"width":"100%","background":"url(http://codegen.caihongy.cn/20230209/f278a1cc5e9f48938a9a65c1c201de9e.jpg) no-repeat center center / 100% 100%","height":"280px"}'></div>
		<div class="box2" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box3" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box4" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box5" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box6" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box7" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box8" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box9" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box10" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
	</div>

</div>
<div class="lists" :style='{"padding":"0px","boxShadow":"0px 0px 0px #eee","margin":"40px 0 0px","borderColor":"#98c6e2","display":"block","borderRadius":"0px","flexWrap":"wrap","background":"url() no-repeat center bottom / 100% auto,#fff","borderWidth":"0 0 0px","width":"100%","position":"relative","borderStyle":"dotted","height":"auto","order":"4"}'>
	
	<div class="title" :style='{"width":"80%","padding":"0px 20px 0 0px","margin":"0px auto 40px","position":"relative","background":"url(http://codegen.caihongy.cn/20230208/a6f9d67e1ec04a1dbbb264deb83c53bc.png) no-repeat right top / auto 100%,url(http://codegen.caihongy.cn/20230208/bd01c0afeace43b5bf2e9be87a292858.png) no-repeat left top / auto 100%,url(http://codegen.caihongy.cn/20230208/128206ec886647b8ba4092200f05299a.png) repeat-x center top / auto 100%","height":"90px"}'>
	  <span :style='{"padding":"0 20px 0 60px","color":"#4e4e4e","background":"none","fontSize":"24px","lineHeight":"76px","textShadow":"0px 0px 0px #eee","fontWeight":"600"}'>公益资讯展示</span>
	</div>
	
	
	
	<!-- 样式二 -->
	<div class="list list2 index-pv1" :style='{"padding":"0 7%","flexWrap":"wrap","background":"none","display":"flex","width":"100%","justifyContent":"space-between","height":"auto"}'>
		<div :style='{"cursor":"pointer","padding":"0px","boxShadow":"0px 0px 0px #eee","margin":"0 0 80px","borderColor":"#eee","display":"flex","flexWrap":"wrap","background":"#fff","borderWidth":"0px","width":"48%","fontSize":"0","position":"relative","borderStyle":"solid","height":"320px"}' v-for="(item,index) in gongyizixunList" class="list-item animation-box" :key="index" @click="toDetail('gongyizixunDetail', item)">
			<img :style='{"padding":"0px","borderColor":"#9dcde9","margin":"40px 0 0","objectFit":"cover","borderWidth":"0px","display":"inline-block","width":"50%","borderStyle":"dotted","height":"100%"}' v-if="preHttp(item.fengmian)" :src="item.fengmian.split(',')[0]" alt="" />
			<img :style='{"padding":"0px","borderColor":"#9dcde9","margin":"40px 0 0","objectFit":"cover","borderWidth":"0px","display":"inline-block","width":"50%","borderStyle":"dotted","height":"100%"}' v-else :src="baseUrl +  (item.fengmian?item.fengmian.split(',')[0]:'')" alt="" />
			<div :style='{"padding":"10px 0px","borderColor":"#f3d7ca #f3d7ca #f3d7ca","overflow":"hidden","alignItems":"center","background":"linear-gradient(180deg, rgba(253,167,69,1) 0%, rgba(253,167,69,1) 50%, rgba(253,108,66,1) 100%)","borderWidth":"0 10px 0","display":"flex","width":"50%","borderStyle":"solid","justifyContent":"center","height":"100%"}' class="item-info">
				<div class="name line1" :style='{"padding":"10px","borderColor":"#9dcde9","margin":"0 10px 0 0","color":"#fff","alignItems":"center","textAlign":"center","display":"flex","justifyContent":"center","overflow":"hidden","borderWidth":"0 0 0px","width":"40px","lineHeight":"1.2","fontSize":"16px","borderStyle":"dotted"}'>{{item.gongyizhuti}}</div>
			</div>
		</div>
	</div>
	
	
	
	
	
	
	
	
	<div @click="moreBtn('gongyizixun')" :style='{"cursor":"pointer","padding":"0 20px","margin":"0px auto 0","borderColor":"#9dcde9","textAlign":"center","display":"inline-block","minWidth":"120px","right":"calc(10% + 20px)","borderRadius":"0px","top":"18px","background":"none","borderWidth":"0px","width":"auto","lineHeight":"40px","position":"absolute","borderStyle":"dotted"}'>
		<span :style='{"padding":"0px","borderColor":"#ccc","margin":"0","color":"#333","background":"none","borderWidth":"0","display":"inline-block","width":"auto","fontSize":"15px","lineHeight":"40px","borderStyle":"solid","height":"40px"}'>查看更多</span>
		<i v-if="true" :style='{"padding":"0","borderColor":"#ccc","margin":"0","color":"#333","borderWidth":"0px","background":"none","display":"inline-block","width":"auto","fontSize":"15px","lineHeight":"40px","borderStyle":"solid","height":"40px"}' class="el-icon-d-arrow-right"></i>
	</div>
	
	<div v-if="true" class="idea" :style='{"padding":"0px","margin":"50px 0 0","flexWrap":"wrap","background":"none","display":"flex","width":"100%","justifyContent":"space-between"}'>
		<div class="box1" :style='{"width":"100%","background":"url(http://codegen.caihongy.cn/20230209/f278a1cc5e9f48938a9a65c1c201de9e.jpg) no-repeat center center / 100% 100%","height":"280px"}'></div>
		<div class="box2" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box3" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box4" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box5" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box6" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box7" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box8" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box9" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box10" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
	</div>

</div>
<div class="lists" :style='{"padding":"0px","boxShadow":"0px 0px 0px #eee","margin":"40px 0 0px","borderColor":"#98c6e2","display":"block","borderRadius":"0px","flexWrap":"wrap","background":"url() no-repeat center bottom / 100% auto,#fff","borderWidth":"0 0 0px","width":"100%","position":"relative","borderStyle":"dotted","height":"auto","order":"4"}'>
	
	<div class="title" :style='{"width":"80%","padding":"0px 20px 0 0px","margin":"0px auto 40px","position":"relative","background":"url(http://codegen.caihongy.cn/20230208/a6f9d67e1ec04a1dbbb264deb83c53bc.png) no-repeat right top / auto 100%,url(http://codegen.caihongy.cn/20230208/bd01c0afeace43b5bf2e9be87a292858.png) no-repeat left top / auto 100%,url(http://codegen.caihongy.cn/20230208/128206ec886647b8ba4092200f05299a.png) repeat-x center top / auto 100%","height":"90px"}'>
	  <span :style='{"padding":"0 20px 0 60px","color":"#4e4e4e","background":"none","fontSize":"24px","lineHeight":"76px","textShadow":"0px 0px 0px #eee","fontWeight":"600"}'>资金去向展示</span>
	</div>
	
	
	
	<!-- 样式二 -->
	<div class="list list2 index-pv1" :style='{"padding":"0 7%","flexWrap":"wrap","background":"none","display":"flex","width":"100%","justifyContent":"space-between","height":"auto"}'>
		<div :style='{"cursor":"pointer","padding":"0px","boxShadow":"0px 0px 0px #eee","margin":"0 0 80px","borderColor":"#eee","display":"flex","flexWrap":"wrap","background":"#fff","borderWidth":"0px","width":"48%","fontSize":"0","position":"relative","borderStyle":"solid","height":"320px"}' v-for="(item,index) in zijinquxiangList" class="list-item animation-box" :key="index" @click="toDetail('zijinquxiangDetail', item)">
			<img :style='{"padding":"0px","borderColor":"#9dcde9","margin":"40px 0 0","objectFit":"cover","borderWidth":"0px","display":"inline-block","width":"50%","borderStyle":"dotted","height":"100%"}' v-if="preHttp(item.fengmian)" :src="item.fengmian.split(',')[0]" alt="" />
			<img :style='{"padding":"0px","borderColor":"#9dcde9","margin":"40px 0 0","objectFit":"cover","borderWidth":"0px","display":"inline-block","width":"50%","borderStyle":"dotted","height":"100%"}' v-else :src="baseUrl +  (item.fengmian?item.fengmian.split(',')[0]:'')" alt="" />
			<div :style='{"padding":"10px 0px","borderColor":"#f3d7ca #f3d7ca #f3d7ca","overflow":"hidden","alignItems":"center","background":"linear-gradient(180deg, rgba(253,167,69,1) 0%, rgba(253,167,69,1) 50%, rgba(253,108,66,1) 100%)","borderWidth":"0 10px 0","display":"flex","width":"50%","borderStyle":"solid","justifyContent":"center","height":"100%"}' class="item-info">
				<div class="name line1" :style='{"padding":"10px","borderColor":"#9dcde9","margin":"0 10px 0 0","color":"#fff","alignItems":"center","textAlign":"center","display":"flex","justifyContent":"center","overflow":"hidden","borderWidth":"0 0 0px","width":"40px","lineHeight":"1.2","fontSize":"16px","borderStyle":"dotted"}'>{{item.zhuti}}</div>
				<div class="name line1" :style='{"padding":"10px","borderColor":"#9dcde9","margin":"0 10px 0 0","color":"#fff","alignItems":"center","textAlign":"center","display":"flex","justifyContent":"center","overflow":"hidden","borderWidth":"0 0 0px","width":"40px","lineHeight":"1.2","fontSize":"16px","borderStyle":"dotted"}'>{{item.fuwuleibie}}</div>
			</div>
		</div>
	</div>
	
	
	
	
	
	
	
	
	<div @click="moreBtn('zijinquxiang')" :style='{"cursor":"pointer","padding":"0 20px","margin":"0px auto 0","borderColor":"#9dcde9","textAlign":"center","display":"inline-block","minWidth":"120px","right":"calc(10% + 20px)","borderRadius":"0px","top":"18px","background":"none","borderWidth":"0px","width":"auto","lineHeight":"40px","position":"absolute","borderStyle":"dotted"}'>
		<span :style='{"padding":"0px","borderColor":"#ccc","margin":"0","color":"#333","background":"none","borderWidth":"0","display":"inline-block","width":"auto","fontSize":"15px","lineHeight":"40px","borderStyle":"solid","height":"40px"}'>查看更多</span>
		<i v-if="true" :style='{"padding":"0","borderColor":"#ccc","margin":"0","color":"#333","borderWidth":"0px","background":"none","display":"inline-block","width":"auto","fontSize":"15px","lineHeight":"40px","borderStyle":"solid","height":"40px"}' class="el-icon-d-arrow-right"></i>
	</div>
	
	<div v-if="true" class="idea" :style='{"padding":"0px","margin":"50px 0 0","flexWrap":"wrap","background":"none","display":"flex","width":"100%","justifyContent":"space-between"}'>
		<div class="box1" :style='{"width":"100%","background":"url(http://codegen.caihongy.cn/20230209/f278a1cc5e9f48938a9a65c1c201de9e.jpg) no-repeat center center / 100% 100%","height":"280px"}'></div>
		<div class="box2" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box3" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box4" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box5" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box6" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box7" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box8" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box9" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
		<div class="box10" :style='{"width":"20%","background":"#fff","display":"none","height":"80px"}'></div>
	</div>

</div>


</div>
</template>

<script>
  export default {
    //数据集合
    data() {
      return {
        baseUrl: '',
        newsList: [],

        zhiyuantuanduiList: [],
        gongyizixunList: [],
        zijinquxiangList: [],
      }
    },
    created() {
      this.baseUrl = this.$config.baseUrl;
      this.getNewsList();
      this.getList();
    },
    //方法集合
    methods: {
      preHttp(str) {
          return str && str.substr(0,4)=='http';
      },
		getNewsList() {
			this.$http.get('news/list', {params: {
				page: 1,
				limit: 4,
			order: 'desc'}}).then(res => {
				if (res.data.code == 0) {
					this.newsList = res.data.data.list;
					
					
				}
			});
		},
		getList() {
          let autoSortUrl = "";
			
			this.$http.get('zhiyuantuandui/list', {params: {
				page: 1,
				limit: 4,
			}}).then(res => {
				if (res.data.code == 0) {
					this.zhiyuantuanduiList = res.data.data.list;
					
					// 商品列表样式五
					
				}
			});
			this.$http.get('gongyizixun/list', {params: {
				page: 1,
				limit: 4,
			}}).then(res => {
				if (res.data.code == 0) {
					this.gongyizixunList = res.data.data.list;
					
					// 商品列表样式五
					
				}
			});
			this.$http.get('zijinquxiang/list', {params: {
				page: 1,
				limit: 4,
			}}).then(res => {
				if (res.data.code == 0) {
					this.zijinquxiangList = res.data.data.list;
					
					// 商品列表样式五
					
				}
			});
		},
		toDetail(path, item) {
			this.$router.push({path: '/index/' + path, query: {detailObj: JSON.stringify(item)}});
		},
		moreBtn(path) {
			this.$router.push({path: '/index/' + path});
		}
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
	.home-preview {
	
		.recommend {
			.list3 .swiper-button-prev {
				left: 10px;
				right: auto;
			}
			
			.list3 .swiper-button-prev::after {
				color: rgb(64, 158, 255);
			}
			
			.list3 .swiper-button-next {
				left: auto;
				right: 10px;
			}
			
			.list3 .swiper-button-next::after {
				color: rgb(64, 158, 255);
			}
			
			.list5 .swiper-button-prev {
				left: 10px;
				right: auto;
			}
			
			.list5 .swiper-button-prev::after {
				color: rgb(64, 158, 255);
        }
        
        .list5 .swiper-button-next {
				left: auto;
				right: 10px;
			}
			
			.list5 .swiper-button-next::after {
				color: rgb(64, 158, 255);
			}
			
			.list5 {
				.swiper-slide-prev {
					position: relative;
					z-index: 3;
				}
		
				.swiper-slide-next {
					position: relative;
					z-index: 3;
				}
		
				.swiper-slide-active {
					position: relative;
					z-index: 5;
				}
			}
			
			.index-pv1 .animation-box {
				transform: rotate(0deg) scale(1) skew(0deg, 0deg) translate3d(0px, 0px, 0px);
				z-index: initial;
			}
			
			.index-pv1 .animation-box:hover {
				transform: translate3d(0px, -10px, 0px);
				-webkit-perspective: 1000px;
				perspective: 1000px;
				transition: 0.3s;
				z-index: 1;
			}
			
			.index-pv1 .animation-box img {
				transform: rotate(0deg) scale(1) skew(0deg, 0deg) translate3d(0px, 0px, 0px);
			}
			
			.index-pv1 .animation-box img:hover {
				filter: brightness(1);
				transform: scale(1);
				-webkit-perspective: 1000px;
				perspective: 1000px;
				transition: all 0.3s ease-in-out 0s;
			}
		}
		
		.news {
			.list3 .swiper-button-prev {
				left: 10px;
				right: auto;
			}
			
			.list3 .swiper-button-prev::after {
				color: rgb(64, 158, 255);
			}
			
			.list3 .swiper-button-next {
				left: auto;
				right: 10px;
			}
			
			.list3 .swiper-button-next::after {
				color: rgb(64, 158, 255);
			}
			
			.list6 .swiper-button-prev {
				left: 10px;
				right: auto;
			}
			
			.list6 .swiper-button-prev::after {
				color: rgb(64, 158, 255);
			}
			
			.list6 .swiper-button-next {
				left: auto;
				right: 10px;
			}
			
			.list6 .swiper-button-next::after {
				color: rgb(64, 158, 255);
			}
			
			.index-pv1 .animation-box {
				transform: rotate(0deg) scale(1) skew(0deg, 0deg) translate3d(0px, 0px, 0px);
				z-index: initial;
			}
			
			.index-pv1 .animation-box:hover {
				transform: translate3d(0px,-10px, 0px);
				-webkit-perspective: 1000px;
				perspective: 1000px;
				transition: 0.3s;
				z-index: 1;
			}
			
			.index-pv1 .animation-box img {
				transform: rotate(0deg) scale(1) skew(0deg, 0deg) translate3d(0px, 0px, 0px);
			}
			
			.index-pv1 .animation-box img:hover {
				filter: brightness(1);
				transform: scale(1);
				-webkit-perspective: 1000px;
				perspective: 1000px;
				transition: all 0.3s ease-in-out 0s;
			}
		}
	
		.lists {
			.list3 .swiper-button-prev {
				left: 10px;
				right: auto;
			}
			
			.list3 .swiper-button-prev::after {
				color: #08b344;
			}
			
			.list3 .swiper-button-next {
				left: auto;
				right: 10px;
        }
        
        .list3 .swiper-button-next::after {
				color: #08b344;
			}
			
			.list5 .swiper-button-prev {
				left: 10px;
				right: auto;
			}
			
			.list5 .swiper-button-prev::after {
				color: rgb(64, 158, 255);
			}
			
			.list5 .swiper-button-next {
            left: auto;
            right: 10px;
			}
			
			.list5 .swiper-button-next::after {
				color: rgb(64, 158, 255);
			}
			
			.list5 {
				.swiper-slide-prev {
					position: relative;
					z-index: 3;
				}
		
				.swiper-slide-next {
					position: relative;
					z-index: 3;
				}
		
				.swiper-slide-active {
					position: relative;
					z-index: 5;
				}
			}
			
			.index-pv1 .animation-box {
				transform: rotate(0deg) scale(1) skew(0deg, 0deg) translate3d(0px, 0px, 0px);
				z-index: initial;
			}
			
			.index-pv1 .animation-box:hover {
				transform: translate3d(0px, -10px, 0px);
				-webkit-perspective: 1000px;
				perspective: 1000px;
				transition: 0.3s;
				z-index: 1;
			}
			
			.index-pv1 .animation-box img {
				transform: rotate(0deg) scale(1) skew(0deg, 0deg) translate3d(0px, 0px, 0px);
			}
			
			.index-pv1 .animation-box img:hover {
				transform: scale(1);
				-webkit-perspective: 1000px;
				perspective: 1000px;
				opacity: 1;
				transition: all 0.3s ease-in-out 0s;
			}
		}
	}
</style>
