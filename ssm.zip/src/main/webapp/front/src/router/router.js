import VueRouter from 'vue-router'

//引入组件
import Index from '../pages'
import Home from '../pages/home/home'
import Login from '../pages/login/login'
import Register from '../pages/register/register'
import Center from '../pages/center/center'
import Storeup from '../pages/storeup/list'
import News from '../pages/news/news-list'
import NewsDetail from '../pages/news/news-detail'
import yonghuList from '../pages/yonghu/list'
import yonghuDetail from '../pages/yonghu/detail'
import yonghuAdd from '../pages/yonghu/add'
import zhiyuantuanduiList from '../pages/zhiyuantuandui/list'
import zhiyuantuanduiDetail from '../pages/zhiyuantuandui/detail'
import zhiyuantuanduiAdd from '../pages/zhiyuantuandui/add'
import gongyizixunList from '../pages/gongyizixun/list'
import gongyizixunDetail from '../pages/gongyizixun/detail'
import gongyizixunAdd from '../pages/gongyizixun/add'
import juanzengwuziList from '../pages/juanzengwuzi/list'
import juanzengwuziDetail from '../pages/juanzengwuzi/detail'
import juanzengwuziAdd from '../pages/juanzengwuzi/add'
import jiuzhuxinxiList from '../pages/jiuzhuxinxi/list'
import jiuzhuxinxiDetail from '../pages/jiuzhuxinxi/detail'
import jiuzhuxinxiAdd from '../pages/jiuzhuxinxi/add'
import wuziquxiangList from '../pages/wuziquxiang/list'
import wuziquxiangDetail from '../pages/wuziquxiang/detail'
import wuziquxiangAdd from '../pages/wuziquxiang/add'
import aixinhuodongList from '../pages/aixinhuodong/list'
import aixinhuodongDetail from '../pages/aixinhuodong/detail'
import aixinhuodongAdd from '../pages/aixinhuodong/add'
import jiaruhuodongList from '../pages/jiaruhuodong/list'
import jiaruhuodongDetail from '../pages/jiaruhuodong/detail'
import jiaruhuodongAdd from '../pages/jiaruhuodong/add'
import zijinquxiangList from '../pages/zijinquxiang/list'
import zijinquxiangDetail from '../pages/zijinquxiang/detail'
import zijinquxiangAdd from '../pages/zijinquxiang/add'

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
	return originalPush.call(this, location).catch(err => err)
}

//配置路由
export default new VueRouter({
	routes:[
		{
      path: '/',
      redirect: '/index/home'
    },
		{
			path: '/index',
			component: Index,
			children:[
				{
					path: 'home',
					component: Home
				},
				{
					path: 'center',
					component: Center,
				},
				{
					path: 'storeup',
					component: Storeup
				},
				{
					path: 'news',
					component: News
				},
				{
					path: 'newsDetail',
					component: NewsDetail
				},
				{
					path: 'yonghu',
					component: yonghuList
				},
				{
					path: 'yonghuDetail',
					component: yonghuDetail
				},
				{
					path: 'yonghuAdd',
					component: yonghuAdd
				},
				{
					path: 'zhiyuantuandui',
					component: zhiyuantuanduiList
				},
				{
					path: 'zhiyuantuanduiDetail',
					component: zhiyuantuanduiDetail
				},
				{
					path: 'zhiyuantuanduiAdd',
					component: zhiyuantuanduiAdd
				},
				{
					path: 'gongyizixun',
					component: gongyizixunList
				},
				{
					path: 'gongyizixunDetail',
					component: gongyizixunDetail
				},
				{
					path: 'gongyizixunAdd',
					component: gongyizixunAdd
				},
				{
					path: 'juanzengwuzi',
					component: juanzengwuziList
				},
				{
					path: 'juanzengwuziDetail',
					component: juanzengwuziDetail
				},
				{
					path: 'juanzengwuziAdd',
					component: juanzengwuziAdd
				},
				{
					path: 'jiuzhuxinxi',
					component: jiuzhuxinxiList
				},
				{
					path: 'jiuzhuxinxiDetail',
					component: jiuzhuxinxiDetail
				},
				{
					path: 'jiuzhuxinxiAdd',
					component: jiuzhuxinxiAdd
				},
				{
					path: 'wuziquxiang',
					component: wuziquxiangList
				},
				{
					path: 'wuziquxiangDetail',
					component: wuziquxiangDetail
				},
				{
					path: 'wuziquxiangAdd',
					component: wuziquxiangAdd
				},
				{
					path: 'aixinhuodong',
					component: aixinhuodongList
				},
				{
					path: 'aixinhuodongDetail',
					component: aixinhuodongDetail
				},
				{
					path: 'aixinhuodongAdd',
					component: aixinhuodongAdd
				},
				{
					path: 'jiaruhuodong',
					component: jiaruhuodongList
				},
				{
					path: 'jiaruhuodongDetail',
					component: jiaruhuodongDetail
				},
				{
					path: 'jiaruhuodongAdd',
					component: jiaruhuodongAdd
				},
				{
					path: 'zijinquxiang',
					component: zijinquxiangList
				},
				{
					path: 'zijinquxiangDetail',
					component: zijinquxiangDetail
				},
				{
					path: 'zijinquxiangAdd',
					component: zijinquxiangAdd
				},
			]
		},
		{
			path: '/login',
			component: Login
		},
		{
			path: '/register',
			component: Register
		},
	]
})
