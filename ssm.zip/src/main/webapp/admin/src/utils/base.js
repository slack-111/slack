const base = {
    get() {
        return {
            url : "http://localhost:8080/ssmx1a0c/",
            name: "ssmx1a0c",
            // 退出到首页链接
            indexUrl: 'http://localhost:8080/ssmx1a0c/front/dist/index.html'
        };
    },
    getProjectName(){
        return {
            projectName: "爱心捐赠系统"
        } 
    }
}
export default base
