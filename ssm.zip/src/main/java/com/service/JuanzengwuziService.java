package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.JuanzengwuziEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.JuanzengwuziVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.JuanzengwuziView;


/**
 * 捐赠物资
 *
 * @author 
 * @email 
 * @date 2023-02-24 16:27:33
 */
public interface JuanzengwuziService extends IService<JuanzengwuziEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<JuanzengwuziVO> selectListVO(Wrapper<JuanzengwuziEntity> wrapper);
   	
   	JuanzengwuziVO selectVO(@Param("ew") Wrapper<JuanzengwuziEntity> wrapper);
   	
   	List<JuanzengwuziView> selectListView(Wrapper<JuanzengwuziEntity> wrapper);
   	
   	JuanzengwuziView selectView(@Param("ew") Wrapper<JuanzengwuziEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<JuanzengwuziEntity> wrapper);
   	

}

