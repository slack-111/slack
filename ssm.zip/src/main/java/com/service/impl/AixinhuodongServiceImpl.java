package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.AixinhuodongDao;
import com.entity.AixinhuodongEntity;
import com.service.AixinhuodongService;
import com.entity.vo.AixinhuodongVO;
import com.entity.view.AixinhuodongView;

@Service("aixinhuodongService")
public class AixinhuodongServiceImpl extends ServiceImpl<AixinhuodongDao, AixinhuodongEntity> implements AixinhuodongService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<AixinhuodongEntity> page = this.selectPage(
                new Query<AixinhuodongEntity>(params).getPage(),
                new EntityWrapper<AixinhuodongEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<AixinhuodongEntity> wrapper) {
		  Page<AixinhuodongView> page =new Query<AixinhuodongView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<AixinhuodongVO> selectListVO(Wrapper<AixinhuodongEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public AixinhuodongVO selectVO(Wrapper<AixinhuodongEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<AixinhuodongView> selectListView(Wrapper<AixinhuodongEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public AixinhuodongView selectView(Wrapper<AixinhuodongEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
