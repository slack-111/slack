package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.JiaruhuodongDao;
import com.entity.JiaruhuodongEntity;
import com.service.JiaruhuodongService;
import com.entity.vo.JiaruhuodongVO;
import com.entity.view.JiaruhuodongView;

@Service("jiaruhuodongService")
public class JiaruhuodongServiceImpl extends ServiceImpl<JiaruhuodongDao, JiaruhuodongEntity> implements JiaruhuodongService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<JiaruhuodongEntity> page = this.selectPage(
                new Query<JiaruhuodongEntity>(params).getPage(),
                new EntityWrapper<JiaruhuodongEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<JiaruhuodongEntity> wrapper) {
		  Page<JiaruhuodongView> page =new Query<JiaruhuodongView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<JiaruhuodongVO> selectListVO(Wrapper<JiaruhuodongEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public JiaruhuodongVO selectVO(Wrapper<JiaruhuodongEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<JiaruhuodongView> selectListView(Wrapper<JiaruhuodongEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public JiaruhuodongView selectView(Wrapper<JiaruhuodongEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
