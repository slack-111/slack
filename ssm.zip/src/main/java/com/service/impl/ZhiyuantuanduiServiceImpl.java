package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.ZhiyuantuanduiDao;
import com.entity.ZhiyuantuanduiEntity;
import com.service.ZhiyuantuanduiService;
import com.entity.vo.ZhiyuantuanduiVO;
import com.entity.view.ZhiyuantuanduiView;

@Service("zhiyuantuanduiService")
public class ZhiyuantuanduiServiceImpl extends ServiceImpl<ZhiyuantuanduiDao, ZhiyuantuanduiEntity> implements ZhiyuantuanduiService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ZhiyuantuanduiEntity> page = this.selectPage(
                new Query<ZhiyuantuanduiEntity>(params).getPage(),
                new EntityWrapper<ZhiyuantuanduiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ZhiyuantuanduiEntity> wrapper) {
		  Page<ZhiyuantuanduiView> page =new Query<ZhiyuantuanduiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<ZhiyuantuanduiVO> selectListVO(Wrapper<ZhiyuantuanduiEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public ZhiyuantuanduiVO selectVO(Wrapper<ZhiyuantuanduiEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<ZhiyuantuanduiView> selectListView(Wrapper<ZhiyuantuanduiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ZhiyuantuanduiView selectView(Wrapper<ZhiyuantuanduiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
