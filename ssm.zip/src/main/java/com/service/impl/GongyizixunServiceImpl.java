package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.GongyizixunDao;
import com.entity.GongyizixunEntity;
import com.service.GongyizixunService;
import com.entity.vo.GongyizixunVO;
import com.entity.view.GongyizixunView;

@Service("gongyizixunService")
public class GongyizixunServiceImpl extends ServiceImpl<GongyizixunDao, GongyizixunEntity> implements GongyizixunService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<GongyizixunEntity> page = this.selectPage(
                new Query<GongyizixunEntity>(params).getPage(),
                new EntityWrapper<GongyizixunEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<GongyizixunEntity> wrapper) {
		  Page<GongyizixunView> page =new Query<GongyizixunView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<GongyizixunVO> selectListVO(Wrapper<GongyizixunEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public GongyizixunVO selectVO(Wrapper<GongyizixunEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<GongyizixunView> selectListView(Wrapper<GongyizixunEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public GongyizixunView selectView(Wrapper<GongyizixunEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
