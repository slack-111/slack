package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.GongyizixunEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.GongyizixunVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.GongyizixunView;


/**
 * 公益资讯
 *
 * @author 
 * @email 
 * @date 2023-02-24 16:27:33
 */
public interface GongyizixunService extends IService<GongyizixunEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<GongyizixunVO> selectListVO(Wrapper<GongyizixunEntity> wrapper);
   	
   	GongyizixunVO selectVO(@Param("ew") Wrapper<GongyizixunEntity> wrapper);
   	
   	List<GongyizixunView> selectListView(Wrapper<GongyizixunEntity> wrapper);
   	
   	GongyizixunView selectView(@Param("ew") Wrapper<GongyizixunEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<GongyizixunEntity> wrapper);
   	

}

