package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.JiaruhuodongEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.JiaruhuodongVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.JiaruhuodongView;


/**
 * 加入活动
 *
 * @author 
 * @email 
 * @date 2023-02-24 16:27:33
 */
public interface JiaruhuodongService extends IService<JiaruhuodongEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<JiaruhuodongVO> selectListVO(Wrapper<JiaruhuodongEntity> wrapper);
   	
   	JiaruhuodongVO selectVO(@Param("ew") Wrapper<JiaruhuodongEntity> wrapper);
   	
   	List<JiaruhuodongView> selectListView(Wrapper<JiaruhuodongEntity> wrapper);
   	
   	JiaruhuodongView selectView(@Param("ew") Wrapper<JiaruhuodongEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<JiaruhuodongEntity> wrapper);
   	

}

