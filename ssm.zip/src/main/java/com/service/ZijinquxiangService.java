package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ZijinquxiangEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ZijinquxiangVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ZijinquxiangView;


/**
 * 资金去向
 *
 * @author 
 * @email 
 * @date 2023-02-24 16:27:33
 */
public interface ZijinquxiangService extends IService<ZijinquxiangEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ZijinquxiangVO> selectListVO(Wrapper<ZijinquxiangEntity> wrapper);
   	
   	ZijinquxiangVO selectVO(@Param("ew") Wrapper<ZijinquxiangEntity> wrapper);
   	
   	List<ZijinquxiangView> selectListView(Wrapper<ZijinquxiangEntity> wrapper);
   	
   	ZijinquxiangView selectView(@Param("ew") Wrapper<ZijinquxiangEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ZijinquxiangEntity> wrapper);
   	

    List<Map<String, Object>> selectValue(Map<String, Object> params,Wrapper<ZijinquxiangEntity> wrapper);

    List<Map<String, Object>> selectTimeStatValue(Map<String, Object> params,Wrapper<ZijinquxiangEntity> wrapper);

    List<Map<String, Object>> selectGroup(Map<String, Object> params,Wrapper<ZijinquxiangEntity> wrapper);



}

