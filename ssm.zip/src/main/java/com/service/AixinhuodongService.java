package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.AixinhuodongEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.AixinhuodongVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.AixinhuodongView;


/**
 * 爱心活动
 *
 * @author 
 * @email 
 * @date 2023-02-24 16:27:33
 */
public interface AixinhuodongService extends IService<AixinhuodongEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<AixinhuodongVO> selectListVO(Wrapper<AixinhuodongEntity> wrapper);
   	
   	AixinhuodongVO selectVO(@Param("ew") Wrapper<AixinhuodongEntity> wrapper);
   	
   	List<AixinhuodongView> selectListView(Wrapper<AixinhuodongEntity> wrapper);
   	
   	AixinhuodongView selectView(@Param("ew") Wrapper<AixinhuodongEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<AixinhuodongEntity> wrapper);
   	

}

