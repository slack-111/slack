package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.WuziquxiangEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.WuziquxiangVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.WuziquxiangView;


/**
 * 物资去向
 *
 * @author 
 * @email 
 * @date 2023-02-24 16:27:33
 */
public interface WuziquxiangService extends IService<WuziquxiangEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<WuziquxiangVO> selectListVO(Wrapper<WuziquxiangEntity> wrapper);
   	
   	WuziquxiangVO selectVO(@Param("ew") Wrapper<WuziquxiangEntity> wrapper);
   	
   	List<WuziquxiangView> selectListView(Wrapper<WuziquxiangEntity> wrapper);
   	
   	WuziquxiangView selectView(@Param("ew") Wrapper<WuziquxiangEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<WuziquxiangEntity> wrapper);
   	

    List<Map<String, Object>> selectValue(Map<String, Object> params,Wrapper<WuziquxiangEntity> wrapper);

    List<Map<String, Object>> selectTimeStatValue(Map<String, Object> params,Wrapper<WuziquxiangEntity> wrapper);

    List<Map<String, Object>> selectGroup(Map<String, Object> params,Wrapper<WuziquxiangEntity> wrapper);



}

