package com.entity.model;

import com.entity.GongyizixunEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import java.io.Serializable;
 

/**
 * 公益资讯
 * 接收传参的实体类  
 *（实际开发中配合移动端接口开发手动去掉些没用的字段， 后端一般用entity就够用了） 
 * 取自ModelAndView 的model名称
 * @author 
 * @email 
 * @date 2023-02-24 16:27:33
 */
public class GongyizixunModel  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 发布时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date fabushijian;
		
	/**
	 * 公益简要
	 */
	
	private String gongyijianyao;
		
	/**
	 * 公益内容
	 */
	
	private String gongyineirong;
		
	/**
	 * 封面
	 */
	
	private String fengmian;
				
	
	/**
	 * 设置：发布时间
	 */
	 
	public void setFabushijian(Date fabushijian) {
		this.fabushijian = fabushijian;
	}
	
	/**
	 * 获取：发布时间
	 */
	public Date getFabushijian() {
		return fabushijian;
	}
				
	
	/**
	 * 设置：公益简要
	 */
	 
	public void setGongyijianyao(String gongyijianyao) {
		this.gongyijianyao = gongyijianyao;
	}
	
	/**
	 * 获取：公益简要
	 */
	public String getGongyijianyao() {
		return gongyijianyao;
	}
				
	
	/**
	 * 设置：公益内容
	 */
	 
	public void setGongyineirong(String gongyineirong) {
		this.gongyineirong = gongyineirong;
	}
	
	/**
	 * 获取：公益内容
	 */
	public String getGongyineirong() {
		return gongyineirong;
	}
				
	
	/**
	 * 设置：封面
	 */
	 
	public void setFengmian(String fengmian) {
		this.fengmian = fengmian;
	}
	
	/**
	 * 获取：封面
	 */
	public String getFengmian() {
		return fengmian;
	}
			
}
