package com.entity.model;

import com.entity.ZijinquxiangEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import java.io.Serializable;
 

/**
 * 资金去向
 * 接收传参的实体类  
 *（实际开发中配合移动端接口开发手动去掉些没用的字段， 后端一般用entity就够用了） 
 * 取自ModelAndView 的model名称
 * @author 
 * @email 
 * @date 2023-02-24 16:27:33
 */
public class ZijinquxiangModel  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 服务时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date fuwushijian;
		
	/**
	 * 服务地点
	 */
	
	private String fuwudidian;
		
	/**
	 * 服务类别
	 */
	
	private String fuwuleibie;
		
	/**
	 * 服务对象
	 */
	
	private String fuwuduixiang;
		
	/**
	 * 详情
	 */
	
	private String xiangqing;
		
	/**
	 * 封面
	 */
	
	private String fengmian;
		
	/**
	 * 捐赠金额
	 */
	
	private Integer juanzengjine;
		
	/**
	 * 用户账号
	 */
	
	private String yonghuzhanghao;
		
	/**
	 * 团队账号
	 */
	
	private String tuanduizhanghao;
				
	
	/**
	 * 设置：服务时间
	 */
	 
	public void setFuwushijian(Date fuwushijian) {
		this.fuwushijian = fuwushijian;
	}
	
	/**
	 * 获取：服务时间
	 */
	public Date getFuwushijian() {
		return fuwushijian;
	}
				
	
	/**
	 * 设置：服务地点
	 */
	 
	public void setFuwudidian(String fuwudidian) {
		this.fuwudidian = fuwudidian;
	}
	
	/**
	 * 获取：服务地点
	 */
	public String getFuwudidian() {
		return fuwudidian;
	}
				
	
	/**
	 * 设置：服务类别
	 */
	 
	public void setFuwuleibie(String fuwuleibie) {
		this.fuwuleibie = fuwuleibie;
	}
	
	/**
	 * 获取：服务类别
	 */
	public String getFuwuleibie() {
		return fuwuleibie;
	}
				
	
	/**
	 * 设置：服务对象
	 */
	 
	public void setFuwuduixiang(String fuwuduixiang) {
		this.fuwuduixiang = fuwuduixiang;
	}
	
	/**
	 * 获取：服务对象
	 */
	public String getFuwuduixiang() {
		return fuwuduixiang;
	}
				
	
	/**
	 * 设置：详情
	 */
	 
	public void setXiangqing(String xiangqing) {
		this.xiangqing = xiangqing;
	}
	
	/**
	 * 获取：详情
	 */
	public String getXiangqing() {
		return xiangqing;
	}
				
	
	/**
	 * 设置：封面
	 */
	 
	public void setFengmian(String fengmian) {
		this.fengmian = fengmian;
	}
	
	/**
	 * 获取：封面
	 */
	public String getFengmian() {
		return fengmian;
	}
				
	
	/**
	 * 设置：捐赠金额
	 */
	 
	public void setJuanzengjine(Integer juanzengjine) {
		this.juanzengjine = juanzengjine;
	}
	
	/**
	 * 获取：捐赠金额
	 */
	public Integer getJuanzengjine() {
		return juanzengjine;
	}
				
	
	/**
	 * 设置：用户账号
	 */
	 
	public void setYonghuzhanghao(String yonghuzhanghao) {
		this.yonghuzhanghao = yonghuzhanghao;
	}
	
	/**
	 * 获取：用户账号
	 */
	public String getYonghuzhanghao() {
		return yonghuzhanghao;
	}
				
	
	/**
	 * 设置：团队账号
	 */
	 
	public void setTuanduizhanghao(String tuanduizhanghao) {
		this.tuanduizhanghao = tuanduizhanghao;
	}
	
	/**
	 * 获取：团队账号
	 */
	public String getTuanduizhanghao() {
		return tuanduizhanghao;
	}
			
}
