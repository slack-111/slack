package com.dao;

import com.entity.GongyizixunEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.GongyizixunVO;
import com.entity.view.GongyizixunView;


/**
 * 公益资讯
 * 
 * @author 
 * @email 
 * @date 2023-02-24 16:27:33
 */
public interface GongyizixunDao extends BaseMapper<GongyizixunEntity> {
	
	List<GongyizixunVO> selectListVO(@Param("ew") Wrapper<GongyizixunEntity> wrapper);
	
	GongyizixunVO selectVO(@Param("ew") Wrapper<GongyizixunEntity> wrapper);
	
	List<GongyizixunView> selectListView(@Param("ew") Wrapper<GongyizixunEntity> wrapper);

	List<GongyizixunView> selectListView(Pagination page,@Param("ew") Wrapper<GongyizixunEntity> wrapper);
	
	GongyizixunView selectView(@Param("ew") Wrapper<GongyizixunEntity> wrapper);
	

}
