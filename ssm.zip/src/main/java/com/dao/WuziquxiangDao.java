package com.dao;

import com.entity.WuziquxiangEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.WuziquxiangVO;
import com.entity.view.WuziquxiangView;


/**
 * 物资去向
 * 
 * @author 
 * @email 
 * @date 2023-02-24 16:27:33
 */
public interface WuziquxiangDao extends BaseMapper<WuziquxiangEntity> {
	
	List<WuziquxiangVO> selectListVO(@Param("ew") Wrapper<WuziquxiangEntity> wrapper);
	
	WuziquxiangVO selectVO(@Param("ew") Wrapper<WuziquxiangEntity> wrapper);
	
	List<WuziquxiangView> selectListView(@Param("ew") Wrapper<WuziquxiangEntity> wrapper);

	List<WuziquxiangView> selectListView(Pagination page,@Param("ew") Wrapper<WuziquxiangEntity> wrapper);
	
	WuziquxiangView selectView(@Param("ew") Wrapper<WuziquxiangEntity> wrapper);
	

    List<Map<String, Object>> selectValue(@Param("params")Map<String, Object> params,@Param("ew") Wrapper<WuziquxiangEntity> wrapper);

    List<Map<String, Object>> selectTimeStatValue(@Param("params") Map<String, Object> params,@Param("ew") Wrapper<WuziquxiangEntity> wrapper);

    List<Map<String, Object>> selectGroup(@Param("params") Map<String, Object> params,@Param("ew") Wrapper<WuziquxiangEntity> wrapper);



}
