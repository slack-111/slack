package com.dao;

import com.entity.JiaruhuodongEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.JiaruhuodongVO;
import com.entity.view.JiaruhuodongView;


/**
 * 加入活动
 * 
 * @author 
 * @email 
 * @date 2023-02-24 16:27:33
 */
public interface JiaruhuodongDao extends BaseMapper<JiaruhuodongEntity> {
	
	List<JiaruhuodongVO> selectListVO(@Param("ew") Wrapper<JiaruhuodongEntity> wrapper);
	
	JiaruhuodongVO selectVO(@Param("ew") Wrapper<JiaruhuodongEntity> wrapper);
	
	List<JiaruhuodongView> selectListView(@Param("ew") Wrapper<JiaruhuodongEntity> wrapper);

	List<JiaruhuodongView> selectListView(Pagination page,@Param("ew") Wrapper<JiaruhuodongEntity> wrapper);
	
	JiaruhuodongView selectView(@Param("ew") Wrapper<JiaruhuodongEntity> wrapper);
	

}
