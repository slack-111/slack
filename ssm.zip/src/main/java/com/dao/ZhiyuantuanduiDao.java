package com.dao;

import com.entity.ZhiyuantuanduiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.ZhiyuantuanduiVO;
import com.entity.view.ZhiyuantuanduiView;


/**
 * 志愿团队
 * 
 * @author 
 * @email 
 * @date 2023-02-24 16:27:33
 */
public interface ZhiyuantuanduiDao extends BaseMapper<ZhiyuantuanduiEntity> {
	
	List<ZhiyuantuanduiVO> selectListVO(@Param("ew") Wrapper<ZhiyuantuanduiEntity> wrapper);
	
	ZhiyuantuanduiVO selectVO(@Param("ew") Wrapper<ZhiyuantuanduiEntity> wrapper);
	
	List<ZhiyuantuanduiView> selectListView(@Param("ew") Wrapper<ZhiyuantuanduiEntity> wrapper);

	List<ZhiyuantuanduiView> selectListView(Pagination page,@Param("ew") Wrapper<ZhiyuantuanduiEntity> wrapper);
	
	ZhiyuantuanduiView selectView(@Param("ew") Wrapper<ZhiyuantuanduiEntity> wrapper);
	

}
