package com.dao;

import com.entity.AixinhuodongEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.AixinhuodongVO;
import com.entity.view.AixinhuodongView;


/**
 * 爱心活动
 * 
 * @author 
 * @email 
 * @date 2023-02-24 16:27:33
 */
public interface AixinhuodongDao extends BaseMapper<AixinhuodongEntity> {
	
	List<AixinhuodongVO> selectListVO(@Param("ew") Wrapper<AixinhuodongEntity> wrapper);
	
	AixinhuodongVO selectVO(@Param("ew") Wrapper<AixinhuodongEntity> wrapper);
	
	List<AixinhuodongView> selectListView(@Param("ew") Wrapper<AixinhuodongEntity> wrapper);

	List<AixinhuodongView> selectListView(Pagination page,@Param("ew") Wrapper<AixinhuodongEntity> wrapper);
	
	AixinhuodongView selectView(@Param("ew") Wrapper<AixinhuodongEntity> wrapper);
	

}
